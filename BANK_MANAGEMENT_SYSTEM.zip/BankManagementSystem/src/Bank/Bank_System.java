package Bank;



		import java.util.Scanner;
		public class Bank_System
		{

			public static void main(String[] args)
			{
			
		int balance=10000,withdraw,deposite,number;
		Scanner Sc=new Scanner(System.in);

		while(true)
		{
			System.out.println("Welcome TO Bank");  
		    System.out.println("1.for Withdrawn");  
		    System.out.println("2. for Deposite");  
		    System.out.println("3. for Check Balance");  
		    System.out.println("4.for EXIT");  
		    System.out.print("Choose the operation you want to perform:");  
		      
		   number = Sc.nextInt(); 
		   switch(number) 
		  
		   {  
		      
		   case 1:  
		System.out.print("Enter amount to be withdrawn :");  
		             withdraw = Sc.nextInt();  
		     
		             if(withdraw <0) {
		           	  System.out.println("sorry,but your amount must be positive");
		             }           
		             else if(balance >= withdraw) 
		              {  
		                    balance = balance - withdraw;  
		                   System.out.println("Balance amount is:"+balance);  
		                     System.out.println("Please collect your money");  
		                }  
		 
		                  else  
		                  {  
		                          System.out.println("You dont have enough money for withdraw");  
		                      }  
		                       System.out.println(" ");  
		break;  

		   case 2:  
		       
		       System.out.println("Enter amount to be deposited:");  
		                      deposite = Sc.nextInt();  
		                      if(deposite<0)
		                      { 
		                    	  System.out.println("sorry,but your amount must be positive");
		                       }
		                      else
		                      {
		                    	  balance = balance + deposite;  
		                      
		                     System.out.println("Balance amount is:"+ balance);  
		                     
		       System.out.println("Money has been deposited successfully !!!");  
		                         System.out.println(" ");  
		                      }
		       break;  
		  
		   case 3:  
		       
		       System.out.println("Balance of your amount is:"+balance);  
		       System.out.println(" ");  
		      
		       break;  
		  
		    case 4:  
		    	System.out.println(" THANK YOU !!!");  
		       System.exit(0);  
		        
		           }  
		       }  
		   }

		}

	
